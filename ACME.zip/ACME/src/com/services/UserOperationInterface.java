package com.services;

import com.model.User;

public interface UserOperationInterface {

	public User userDetails(int userid);

}
