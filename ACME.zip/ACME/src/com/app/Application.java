package com.app;

public class Application {

	private static void run() {
		final Controller controller = new Controller();
		controller.run();
	}

	public static void main(String[] args) {

		Application.run();

	}

}
