package serviceI;

public interface dropClass {

}
