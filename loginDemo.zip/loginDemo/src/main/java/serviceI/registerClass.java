package serviceI;

public interface registerClass {

}
