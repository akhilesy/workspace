package bean;

import java.util.ArrayList;

public class MyCourses {
	

	private String courseId;
	private String title;
	private String grade;
	
	
	
	
	
	public String getCourseId() {
		return courseId;
	}





	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}





	public String getTitle() {
		return title;
	}





	public void setTitle(String title) {
		this.title = title;
	}





	public String getGrade() {
		return grade;
	}





	public void setGrade(String grade) {
		this.grade = grade;
	}





	public void setMyCourses(ArrayList<String> myRegCourses) {
		
		
		// TODO Auto-generated method stub
		
	}

}
